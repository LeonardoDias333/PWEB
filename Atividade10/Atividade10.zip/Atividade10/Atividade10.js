var Aluno1 = {
    ra: '0030482023042',
    nome: 'Leonardo de Melo Dias'
  }
  alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);
  
  Aluno1.ra = '0030482023021';
  Aluno1.nome = 'Lucas Maximiano';
  alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);
  
  Aluno1['ra'] = '0030482023046';
  Aluno1['nome'] = 'Fidervan Silva';
  alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);
