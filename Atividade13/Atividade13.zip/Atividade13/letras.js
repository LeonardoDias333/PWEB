const toUpper = () =>{
      const input = document.body.querySelector('#inputText');
      input.value = input.value.toUpperCase();
};

const toLower = () =>{
      const input = document.body.querySelector('#inputText');
      input.value = input.value.toLowerCase();
};



